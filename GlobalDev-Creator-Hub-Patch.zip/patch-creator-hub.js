#!/usr/bin/env node
/**
 * GlobalDev Hub social-first patch
 * Usage: node patch-creator-hub.js creator-hub.html
 *
 * Makes a backup beside the source, then patches the existing page in place.
 * It does not change Supabase schema or deploy to GitHub.
 */
const fs = require("node:fs");
const path = require("node:path");

const file = process.argv[2] || "creator-hub.html";
if (!fs.existsSync(file)) {
  console.error("File not found:", file);
  process.exit(1);
}
let html = fs.readFileSync(file, "utf8");
const original = html;

function replaceOnce(from, to, label) {
  const count = html.split(from).length - 1;
  if (count !== 1) throw new Error(`${label}: expected one match, found ${count}`);
  html = html.replace(from, to);
}

replaceOnce(
  '<a class="gdh-story gdh-story-create" href="#gdhQuickPostForm"><span>＋</span><strong>Create story</strong><small>Share a moment</small></a>',
  '<button class="gdh-story gdh-story-create" id="gdhCreateStory" type="button"><span>＋</span><strong>Create story</strong><small>Share a moment</small></button>',
  "Convert Create Story to action button"
);

replaceOnce(
  'let currentUser=null,activeFilter="all",searchTerm="",redirecting=false,savingPost=false,selectedMusic=null,editingMusic=null,creatorDirectory=[],followingIds=new Set(),peopleMode="all";',
  'let currentUser=null,activeFilter="all",searchTerm="",redirecting=false,savingPost=false,selectedMusic=null,editingMusic=null,creatorDirectory=[],followingIds=new Set(),peopleMode="all",quickPostKind="status",reelsMode=false;',
  "Add story and Reels state"
);

replaceOnce(
  'const kind=file?(file.type.startsWith("video/")?"video":"image"):selectedMusic?"music":"status";const category=kind==="video"?"videos":kind==="image"?"images":"articles";',
  'const kind=quickPostKind==="story"?"story":file?(file.type.startsWith("video/")?"video":"image"):selectedMusic?"music":"status";const category=kind==="video"?"videos":kind==="image"?"images":"articles";',
  "Publish selected story type"
);

replaceOnce(
  '$("gdhQuickPostForm").reset();selectedMusic=null;$("gdhSelectedMusicPreview").textContent="";',
  '$("gdhQuickPostForm").reset();quickPostKind="status";$("gdhCreateStory").querySelector("strong").textContent="Create story";$("gdhQuickText").placeholder="Write something…";selectedMusic=null;$("gdhSelectedMusicPreview").textContent="";',
  "Reset composer after post"
);

replaceOnce(
  'function setupQuickComposer(){const form=$("gdhQuickPostForm");form.addEventListener("submit",publishQuickPost);setupEmojiPicker();',
  'function setupQuickComposer(){const form=$("gdhQuickPostForm");form.addEventListener("submit",publishQuickPost);$("gdhCreateStory")?.addEventListener("click",()=>{quickPostKind="story";$("gdhCreateStory").querySelector("strong").textContent="Story mode active";$("gdhQuickText").placeholder="Share a moment — stories disappear after 24 hours.";say("gdhQuickPostStatus","Story mode: add text, a photo or a video, then publish. Stories are shown for 24 hours.");$("gdhQuickPostForm").scrollIntoView({behavior:"smooth",block:"center"});$("gdhQuickText").focus()});setupEmojiPicker();',
  "Add story composer action"
);

replaceOnce(
  'function setupSocialChrome(){const menu=$("gdhMenu"),toggle=$("gdhMenuButton");',
  `async function loadStories(){const strip=$(".gdh-stories");if(!strip)return;strip.querySelectorAll("[data-gdh-story-card]").forEach(n=>n.remove());const cutoff=Date.now()-24*60*60*1000;const {data,error}=await supabase.from("creator_posts").select("id,creator_id,title,description,content,media_path,created_at,published_at").eq("status","published").order("created_at",{ascending:false}).limit(100);if(error){console.info("Stories could not be loaded:",error.message);return}const stories=(data||[]).filter(p=>unpackPostContent(p.content).kind==="story"&&new Date(p.created_at||p.published_at).getTime()>=cutoff);const names=await getAuthorNames([...new Set(stories.map(p=>p.creator_id))]);for(const p of stories){const parsed=unpackPostContent(p.content);const card=document.createElement("button");card.type="button";card.className="gdh-story";card.dataset.gdhStoryCard="true";const who=names.get(p.creator_id)||"Member";const heading=document.createElement("strong");heading.textContent=who;const sub=document.createElement("small");sub.textContent=parsed.text||p.title||"View story";const icon=document.createElement("span");icon.textContent=p.media_path?(p.media_path.match(/\\\\.(mp4|webm)$/i)?"▶️":"📷"):"💬";card.append(icon,heading,sub);card.addEventListener("click",()=>{const target=document.querySelector('[data-post-id="'+p.id+'"]');if(target)target.scrollIntoView({behavior:"smooth",block:"center"});else say("gdhQuickPostStatus","Refresh the feed to view this story post.")});strip.append(card)}}\\nfunction setupSocialChrome(){const menu=$("gdhMenu"),toggle=$("gdhMenuButton");`,
  "Add 24-hour story strip loader"
);

replaceOnce(
  'const card=text(box,"article","","gdh-content-card");card.dataset.category=p.category;',
  'const card=text(box,"article","","gdh-content-card");card.dataset.category=p.category;card.dataset.postId=p.id;',
  "Tag feed cards for story navigation"
);

replaceOnce(
  '$("gdhReelsButton")?.addEventListener("click",()=>{activeFilter="videos";',
  '$("gdhReelsButton")?.addEventListener("click",()=>{reelsMode=!reelsMode;$("gdhPublishedContent").classList.toggle("gdh-reels-mode",reelsMode);$("gdhReelsButton").textContent=reelsMode?"↩ Exit Reels":"▶ Explore videos & Reels";activeFilter="videos";',
  "Add dedicated Reels feed mode"
);

replaceOnce(
  'await Promise.all([loadMyPosts(),loadCreatorDirectory(),loadPublishedPosts(),loadNotifications()]);setupFeedRealtime()}',
  'await Promise.all([loadMyPosts(),loadCreatorDirectory(),loadPublishedPosts(),loadNotifications(),loadStories()]);setupFeedRealtime()}',
  "Load stories at sign-in"
);

replaceOnce(
  '</style></head>',
  '#gdhPublishedContent.gdh-reels-mode{display:grid;gap:18px}#gdhPublishedContent.gdh-reels-mode .gdh-content-card{max-width:520px;margin-inline:auto;width:100%}#gdhPublishedContent.gdh-reels-mode .gdh-video-card .gdh-video-player{width:100%;max-height:78vh;aspect-ratio:9/16;object-fit:cover;background:#050505}#gdhPublishedContent.gdh-reels-mode .gdh-content-card:not(.gdh-video-card){display:none}\\n</style></head>',
  "Add vertical Reels styling"
);

if (html === original) throw new Error("No changes made.");
const backup = file + ".before-globaldev-social-patch.bak";
fs.writeFileSync(backup, original, "utf8");
fs.writeFileSync(file, html, "utf8");
console.log("Patched:", path.resolve(file));
console.log("Backup:", path.resolve(backup));
console.log("Stories loader:", html.includes("async function loadStories()"));
console.log("Story publishing:", html.includes('quickPostKind==="story"'));
console.log("Reels mode:", html.includes("gdh-reels-mode"));
console.log("Reminder: Stories/Reels use existing creator_posts storage; verify RLS and bucket access.");
